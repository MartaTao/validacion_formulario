<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $texto = $_POST["texto"];
            $texto = strtoupper($texto);
            $clave = $_POST["clave"];
            $abecedario="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            $texto_codif="";
            $aux;
            
            for($i=0;$i<strlen($texto);$i++){
                echo "$i";
               if(strstr($texto,$i,$i+1)!=" "){
                   $pos=strpos($abecedario,strstr($texto,$i,$i+1));
                   $suma = $pos+$clave;
                   if($suma>25){
                       $aux = $suma-26;
                       $texto_codif= $texto_codif.strstr($abecedario,$aux,$aux+1);
                   }else{
                       $texto_codif= $texto_codif.strstr($abecedario,$suma,$suma+1);
                   }
               }else{
                   $texto_codif= $texto_codif.strstr($i,$i+1);
               }
            }
            echo "$texto_codif";
        ?>
    </body>
</html>
